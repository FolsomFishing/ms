<?php include 'templates/head_top.php'; ?>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title>Moto-Stops and Pros</title>
		<link href="styles.css" rel="stylesheet" type="text/css"/>
		<meta name="description" content="Moto-Stop recommended brands and products."/>
		<meta name="keywords" content="Moto-Stop, affiliates, recommendations"/>
	<?php include 'templates/analytics.php'; ?>
</head>
	
	<body id="page2">
	
		<div id="container">
		
			<?php include 'templates/header.php'; ?>
			
			<?php include 'templates/navigation.php'; ?>
			
			<div id="outerMain">
			
				<div id="main">
				
					<div id="ltCol-int">
					
						<h1>Links</h1>
						<h2>Friendly Back Links</h2>
						
						<hr>
						
						<A href="http://www.fintalk.com/"><B>Deep Sea Fishing</B></A> - Offering fishing charters, detailed sport fishing reports, and a featured sportsman's fishing forum for all anglers and fishing enthusiasts from Alaska to Florida.<br><br>
						
						Boatle.com <a href="http://www.boatle.com">Boating Directory</a><br><br>
						
						<a href="http://www.ultimatebass.com">Visit Ultimate Bass</a>


													
					</div><!-- ltCol-int -->
						
						
						
					<?php include 'templates/sidebar.php'; ?>
					
					<div class="spanHeight"></div>
					
				</div><!-- main -->
				
				<div id="mainFoot">
				
				</div><!-- mainFoot -->
				
			</div><!-- outerMain -->
			
			<div id="foot">
			
			</div><!-- foot -->
			
		</div><!-- container -->
		
		<div id="pageSpanBtm">
		</div><!-- pageSpanBtm -->
		
	</body><!-- End of Page 1 -->
	
</html>
