<script type="text/javascript" src="http://mediaplayer.yahoo.com/js"></script>

<a href="http://www.anthonyhorndesign.com/test/images/MOTOSTOP.mp3"></a>